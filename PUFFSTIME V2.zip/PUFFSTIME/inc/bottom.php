    
    <aside>
        <img src="<?= RACINE ?>images/logo.png" alt="logo" >
        <img src="<?= RACINE ?>images/logo.png" alt="logo" >
        <img src="<?= RACINE ?>images/logo.png" alt="logo" >
    </aside>

    <footer> &copy, copyright> </footer>

</body>
</html>
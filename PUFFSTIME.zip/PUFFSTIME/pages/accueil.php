<?php
    include "../inc/top.php"
?>
    <main>
        <h2> 1ère page </h2>
    </main>

<?php
    include "../inc/bottom.php"
?>
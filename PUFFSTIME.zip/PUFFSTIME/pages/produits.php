<?php
    include "../inc/top.php"
?>
    <main>
        <h2> Liste des produits disponibles </h2>
    </main>

<?php
    include "../inc/bottom.php"
?>